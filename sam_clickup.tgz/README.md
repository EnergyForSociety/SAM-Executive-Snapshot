# SAM Executive Snapshot

ภาพรวมการขาย การผลิต ต้นทุนสารเคมี และงานซ่อมบำรุง ของ SAM WATER SUPPLY สำหรับ CEO และผู้บริหาร
**สถานะ: รุ่นตรวจรับภายใน — ใช้ข้อมูลจริงแบบ Snapshot (ไม่ใช่ข้อมูลสด) ห้ามเผยแพร่สู่สาธารณะ**

## เปิดใช้งาน

**เว็บใช้งานจริง (ผู้บริหาร):** https://energyforsociety.github.io/SAM-Executive-Snapshot/ — เข้าสู่ระบบด้วยบัญชี Microsoft 365 ของบริษัท
ต้องอยู่ในกลุ่ม `sam_dashboard_viewers` และมีสิทธิ์อ่านไฟล์กุญแจใน SharePoint · ข้อมูลบน GitHub เป็นข้อมูลเข้ารหัส AES-256-GCM

**ทดสอบในเครื่อง (ผู้พัฒนา):** `node scripts/serve.js` แล้วเปิด http://127.0.0.1:8090/web/ (อ่าน `data/snapshot.json` ไม่เข้ารหัส เฉพาะเครื่องนี้)
การดับเบิลคลิกเปิด `web/index.html` โดยตรงจะไม่ทำงาน เพราะเบราว์เซอร์ไม่ให้ไฟล์ในเครื่องโหลดข้อมูล

ธีม: ปุ่ม อัตโนมัติ / สว่าง / มืด ที่หัวเว็บ (จำค่าไว้ในเบราว์เซอร์) · มีแอนิเมชันตอนเปิดหน้า และปิดอัตโนมัติถ้าเครื่องตั้งค่าลดการเคลื่อนไหว

## สร้างและเผยแพร่เว็บ (เหมือน STAR dashboard)

```
python3 scripts/build_snapshot.py
node scripts/build-static.js --key C:\mcp\keys\sam-dash-key.txt --out site
```

- กุญแจของ SAM แยกจาก STAR/HEA เก็บนอก repo · ครั้งแรกสคริปต์สร้างกุญแจให้ แล้วอัปโหลดไฟล์กุญแจไป SharePoint แชร์เฉพาะกลุ่ม `sam_dashboard_viewers` (สิทธิ์ View)
- ใส่ `groupId` และ `keyShareUrl` ใน `static/auth-config.js` แล้ว build ใหม่
- ใช้ App registration เดิม "CCC Staff Status Login" — เพิ่ม Redirect URI (SPA) `https://energyforsociety.github.io/SAM-Executive-Snapshot/`
- commit และ push ด้วย GitHub Desktop · GitHub Pages ใช้ GitHub Actions (`.github/workflows/pages.yml`) เผยแพร่โฟลเดอร์ `site/` เหมือน STAR — ตั้งค่า Settings → Pages → Source: **GitHub Actions**
- สคริปต์ build ตรวจว่าไม่มีข้อมูลจริงที่ไม่เข้ารหัสในโฟลเดอร์ `site/` ก่อนจบ

## หน้าจอ

เมนู 7 หมวดตามกรอบผู้บริหาร (บางหมวดมีหน้าย่อยเป็นแถบเลือกด้านบนของเนื้อหา)

| หมวด | หน้าย่อย | เนื้อหา |
|---|---|---|
| Executive `#/exec` | – | KPI 5 ตัวที่มีข้อมูลจริง · ตาราง KPI ที่ยังแสดงไม่ได้พร้อมเหตุผล · กราฟยอดเรียกเก็บและต้นทุน PO รายเดือน · อันดับพื้นที่ · CEO Insights · รายการต้องติดตาม |
| การขาย `#/sales` | ยอดเรียกเก็บและพื้นที่ | ผลงานรายพื้นที่ แยกส่วนงานบริหาร · ประเภทบริการและรายการหัก · ตาราง BL รายบรรทัด |
| | ลูกค้าใหม่และโอกาสขาย | ยังไม่มีแหล่งข้อมูล CRM/BD — แสดงรายการข้อมูลที่ต้องได้รับก่อน |
| การเงิน `#/fin` | งบบริหาร (P&L) และต้นทุน | งบรายเดือนจาก `get_ledger` · กลุ่มที่ใช้วัดผลได้เทียบกลุ่มที่ถูกรายการปรับครอบ · สถานะรายเดือน · เอกสารรายการปรับ · ตารางรายบัญชี |
| | ลูกหนี้และการรับชำระ | BL ที่ยังไม่รับชำระ · IV ค้างรับรอกระทบยอด · ยอดยกมาปี 2568 · อายุหนี้ · ความสัมพันธ์ BL → IV |
| | เจ้าหนี้และภาระจัดซื้อ | ครบกำหนดแล้ว / 7 วัน / 30 วัน · ตามผู้ขาย พื้นที่ ประเภท · ภาระ PO แยกจากเจ้าหนี้ |
| โครงการ `#/proj` | ภาพรวมตามแผนธุรกิจ | งานจริงจาก **ClickUp** (SAM Space อ่านอย่างเดียว) · งานหลัก/งานย่อยนับแยกกัน · โครงการส่งมอบที่ยืนยันแล้ว · รายการที่ยังจัดประเภทแบบข้อเสนอ · งานเกินกำหนด/ไม่มีกำหนดส่ง · ตารางลำดับชั้นขยาย-ย่อ · ประเด็นที่ต้องดำเนินการพร้อม Task ID และลิงก์ ClickUp · ภาระงานตามจำนวนรายการ (**ไม่ใช่** Resource Utilization) |
| | แผนงานตามแผนธุรกิจ 6 แผน (CPF · New Business · Reject water · Sales · UF membrane · leasing/leasehold) | หนึ่ง List ใน ClickUp = หนึ่งแผนงาน · เหตุผลการจัดประเภทและสิ่งที่ต้องยืนยันรายงาน · งานและงานย่อยของแผนนั้น |
| กลยุทธ์ `#/strat` | – | การเติบโตของยอดเรียกเก็บและปริมาณน้ำ · โครงสร้างรายได้ตามเฟส · แนวโน้มรายเดือน · การเติบโตตามประเภทบริการ · อันดับพื้นที่สะสม (ไม่มี CLV) |
| ปฏิบัติการ `#/ops` | การผลิตและสารเคมี | ปริมาณน้ำรับจริง เทียบสัญญา / แผน CP / แผนธุรกิจ / ปีก่อน รายพื้นที่ (ไฟล์ OM) · PO สารเคมีรายเดือน และบาท/ลบ.ม. รายพื้นที่ |
| | Maintenance Snapshot | ใบงานแจ้งซ่อม (SLA ค้าง เสียซ้ำ อาการ/วิธีซ่อม) · PO ซ่อมบำรุง/สินทรัพย์ · จับคู่ใบงาน↔PO ที่เป็นไปได้ (รอยืนยัน) |
| สถานะข้อมูล `#/data` | – | ชุดข้อมูล เวลาที่ดึง ผลการตรวจ 34 ข้อ ข้อจำกัด mapping พื้นที่ และนิยาม KPI |

ลิงก์เดิมของเว็บรุ่นก่อน (`#/billing` `#/recv` `#/pay` `#/maint`) ยังใช้ได้ ระบบพาไปหน้าย่อยที่ถูกต้องให้เอง
หน้าสัญญาและความเสี่ยงซ่อนไว้จนกว่าจะเข้าถึงข้อมูลสัญญาได้ (สคริปต์นำเข้าสัญญายังอยู่)

ทุก KPI กราฟ และแถวกดดูเอกสารที่ใช้คำนวณได้ · ตารางค้นหา กรอง เรียง แบ่งหน้า และส่งออก CSV (ป้องกัน formula injection) · ปุ่ม "พิมพ์ / บันทึก PDF" ใช้กับหน้า Executive

## โครงสร้าง (แยก 5 ชั้น)

```
scripts/ingest_session.py    1) Source adapter — เก็บ response ดิบจาก TRCLOUD (อ่านอย่างเดียว) → raw/
raw/                         2) Raw snapshot + raw/_manifest.json (เครื่องมือ พารามิเตอร์ เวลาที่ดึง จำนวนแถว)
scripts/build_snapshot.py    3) Normalization + ความสัมพันธ์เอกสาร + การตรวจ → data/snapshot.json
web/metrics.js               4) Metric calculations (ไม่มี DOM · ทดสอบด้วย node)
web/app.js, index.html, styles.css   5) Dashboard UI
scripts/import_om.py         นำเข้า Excel ของ OM → data/om.json (+ประวัติ revision)
scripts/import_maintenance.py นำเข้า Excel ใบงานแจ้งซ่อม → data/maintenance.json (มีชื่อผู้แจ้งซ่อมและผู้รับผิดชอบตามไฟล์ต้นฉบับ)
scripts/import_contracts.py  นำเข้าทะเบียนสัญญา (CSV) → data/contracts.json
scripts/ingest_clickup.py    Source adapter ของ ClickUp — เก็บ response ดิบ (อ่านอย่างเดียว) → raw/clickup/ + _manifest.json
scripts/import_clickup.py    ClickUp → data/projects.json (dedupe ด้วย Task ID · ผูก parent-child · ชั้นจำแนกประเภท · ธงประเด็น)
config/project_classification.csv  ชั้นจำแนกงานของ Dashboard (type · proposed/confirmed · เหตุผล · หลักฐาน · ผู้ยืนยัน) — ไม่แก้ ClickUp ต้นทาง
config/area_mapping.json     department ↔ รหัสพื้นที่ OM ↔ เฟส
config/settings.json         เกณฑ์เตือนภายใน (แยกจากกำหนดตามสัญญา)
config/pl_mapping.json       การจัดกลุ่มงบบริหารจาก Ledger ตามหัวบัญชี (ฝ่ายบัญชีแก้ไฟล์นี้แล้ว build ใหม่)
templates/                   แม่แบบ CSV สำหรับ OM/ผู้ดูแลสัญญา (A–E)
docs/                        นิยาม KPI · ความพร้อม KPI · การเปลี่ยนแปลงและ mapping เมนู · ผลทดสอบ · รายการข้อมูลที่ขอเพิ่ม · สิ่งที่ต้องยืนยัน
tests/                       ชุดทดสอบ
```

จำนวนเงินคำนวณด้วย `Decimal` ปัดครึ่งขึ้นเป็นสตางค์ต่อบรรทัด แล้วเก็บ/รวมเป็นจำนวนเต็ม (สตางค์) ตลอดทั้งระบบ

## การอัปเดตข้อมูล

ระบบนี้**ไม่มีปุ่ม Refresh** เพราะ Web Server เรียก MCP ของ TRCLOUD เองไม่ได้ — connector ใช้ได้เฉพาะใน session ของผู้ช่วย (Claude)

1. ใน session ของผู้ช่วยที่เชื่อม MCP ของ SAM ให้ดึงรายงานชุดเดิม (ดู `raw/_manifest.json` — เฉพาะเครื่องมือ `get_*` / `search_*`)
2. `python3 scripts/ingest_session.py <transcript.jsonl>` — เก็บ response ดิบลง `raw/` (สคริปต์จะหยุดถ้าพบการเรียกเครื่องมือเขียนข้อมูล)
3. `python3 scripts/build_snapshot.py` — ถ้าชุดข้อมูลหลักไม่ครบ ซ้ำ หรือหัวเอกสารไม่ตรงกับบรรทัด จะ**ไม่เขียนทับ** snapshot เดิม
4. เปิดเว็บใหม่ — แถบสถานะจะแสดงเวลาที่ดึงชุดใหม่

ข้อมูล OM: `python3 scripts/import_om.py om/<ไฟล์>.xlsx` แล้วรันข้อ 3 (ไฟล์เดิมไม่ถูกนับซ้ำ ไฟล์แก้ไขได้ revision ใหม่)
ใบงานแจ้งซ่อม: `python3 scripts/import_maintenance.py om/<ไฟล์>.xlsx` แล้วรันข้อ 3
ทะเบียนสัญญา: กรอก `templates/contracts.csv` → `python3 scripts/import_contracts.py <ไฟล์>` แล้วรันข้อ 3

**งานและโครงการ (ClickUp)** — เส้นทางเดียวกับ TRCLOUD คือดึงใน session ของผู้ช่วยแล้วเก็บเป็นไฟล์ (เว็บบน GitHub Pages เรียก MCP เองไม่ได้):

1. ใน session ที่เชื่อม ClickUp MCP ให้ดึง **เฉพาะเครื่องมืออ่าน**: `get_user` (เอาเวลาและ timezone) · `get_workspace_hierarchy` (space `901811856729`) · `filter_tasks` (space เดียวกัน `include_closed: true`, `subtasks: true`, ดึงจนกว่า `has_more` = false) · `get_task` ของงานหลักทุกตัวพร้อม `include: ["description","subtasks"]` · `get_custom_fields` · `get_time_entries`
2. `python3 scripts/ingest_clickup.py <transcript.jsonl>` → `raw/clickup/` (สคริปต์หยุดทันทีถ้าพบการเรียกเครื่องมือที่เขียน/แก้ ClickUp)
3. `python3 scripts/import_clickup.py` → `data/projects.json` (ไม่เขียนไฟล์ถ้าการตรวจไม่ผ่าน เช่น งานย่อยกำพร้า งานหลักที่ยังไม่จัดประเภท หรือ `filter_tasks` ยังมีหน้าต่อ)
4. ถ้ามีงานหลักใหม่ สคริปต์จะฟ้องว่ายังไม่จัดประเภท — เพิ่มแถวใน `config/project_classification.csv` เป็น `proposed` พร้อมเหตุผลและหลักฐาน **ห้ามใส่ `confirmed` เอง** (ต้องมี `confirmed_by` + `confirmed_on` จากผู้รับผิดชอบ)
5. รันข้อ 3 ของหัวข้อด้านบน (`build_snapshot.py`) แล้ว build เว็บตามปกติ — เวลาที่ดึง ClickUp เก็บแยกจากเวลาที่ดึง TRCLOUD และแสดงแยกกันบนหน้าเว็บ

### ถ้าต้องการเชื่อมต่อสด (ยังไม่ได้ทำ)
ต้องเพิ่ม (ก) สิทธิ์ API ของ TRCLOUD สำหรับ user อ่านอย่างเดียวของ SAM ที่เรียกจากเครื่องเซิร์ฟเวอร์ได้ (ข) adapter ที่เขียนไฟล์ `raw/*.json` + `raw/_manifest.json` รูปแบบเดียวกับ `ingest_session.py` (ค) ที่เก็บ credential นอก source code เช่น environment variable — ชั้น 3–5 ใช้ต่อได้โดยไม่ต้องแก้

## ทดสอบ

```
python3 -m pytest tests/test_pipeline.py -q   # normalization, ปัดเศษ, ช่วงให้บริการ, WHT, ซ้ำ, ทะเบียนสัญญา
node --test tests/metrics.test.js             # BL/IV ไม่ซ้ำ, รายการหัก, อายุหนี้, MTD, ข้อมูลขาด, ตัวกรอง, CSV
node tests/ui_smoke.js <โฟลเดอร์ภาพ>           # ตรวจหน้าจอจริง: 7 หมวด หน้าย่อย ลิงก์เดิม ธีม 3 โหมด + หน้าโครงการจาก ClickUp (ต้องมี Playwright)
node tests/gate_test.js site <กุญแจ>          # จำลอง Microsoft 365: login, สิทธิ์กลุ่ม, กุญแจผิด, ออกจากระบบ
```

ผลล่าสุดและการกระทบยอดอยู่ใน `docs/TEST-RESULTS.md`

## ความปลอดภัย

- ใช้เครื่องมือ TRCLOUD แบบอ่านอย่างเดียว เฉพาะบริษัท SAM · ไม่มี credential ใน source code, frontend หรือ log
- ชุดข้อมูลใบงานแจ้งซ่อมมีชื่อผู้แจ้งซ่อมและผู้รับผิดชอบ (ข้อมูลส่วนบุคคล) — อยู่เฉพาะใน `data/` และในไฟล์ `site/data.enc.js` ที่เข้ารหัส เปิดได้หลังเข้าสู่ระบบและอยู่ในกลุ่มที่ได้รับสิทธิ์เท่านั้น
- `raw/`, `data/`, `om/` เป็นข้อมูลการเงินจริง — เก็บในโฟลเดอร์โครงการนี้เท่านั้น ห้ามขึ้น repository สาธารณะ (ดู `.gitignore`)
- เว็บจริงเปิดได้หลังเข้าสู่ระบบ Microsoft 365 + อยู่ในกลุ่ม `sam_dashboard_viewers` + อ่านไฟล์กุญแจใน SharePoint ได้ (แบบเดียวกับ STAR) · ข้อมูลบน GitHub เข้ารหัสทั้งหมด
- repo เป็นสาธารณะ (เพื่อใช้ GitHub Pages) — `.gitignore` กันข้อมูลดิบ เอกสารที่มีตัวเลขจริง และ mapping พื้นที่ ไม่ให้ขึ้น Git
